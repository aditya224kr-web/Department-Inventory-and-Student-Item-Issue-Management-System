# LabStock — Department Inventory Prototype

A responsive, single-page inventory and student issue-management demo. It works as a static website and can be hosted with GitHub Pages.

## Demo sign-in

- **Student** — username `DFIS2026-014`, password `Student@123`
- **Store manager** — username `manager`, password `Store@123`

## Publish it for laptop and WhatsApp access

1. Create a GitHub repository and upload `index.html` and `README.md` to the repository root.
2. In the repository, open **Settings → Pages**.
3. Select **Deploy from a branch**, choose the `main` branch and `/ (root)`, then save.
4. When GitHub Pages finishes publishing, copy its `https://<account>.github.io/<repository>/` link and share that link over WhatsApp. Anyone with the link can open it in a browser.

The standalone `outputs/index.html` is also included as the deliverable copy.

## Prototype scope

The demo includes seeded example data, browser-local persistence, separate student and manager screens, stock availability checks, 15-day due dates, request and renewal approvals, issue/return flows, overdue flags, history, and CSV export.

This is a front-end demo, not a production system. Login credentials are visible in the page source and can be bypassed; browser-local changes do not synchronize between users or devices. Use a backend with secure authentication, a shared database, role-based authorization, and an email provider before entering real student information or relying on automatic reminders.
